// JScript source code

//contains calls to silverlight.js, examples are below

//setting the alpha-channel in the 'background' parameter drastically affects the cost of rendering


function createSilverlight()

{  
    //example calls, please replace with calls that match your site's requirements    
    //Silverlight.createObject("xaml/piano.xaml", pe, "SlControl1",
                                 //{width:'1024', height:'530', inplaceInstallPrompt:false, background:'white', isWindowless:'false', framerate:'24', enableFramerateCounter:'false', version:'1.0'},
                                 //{onError:null, onLoad:null, onResize:onResize},
                                 //null);
                             
                                 
   //Silverlight.createObjectEx({source: 'xaml/piano.xaml', parentElement:pe, id:'SlControl1', properties:{width:'1024', height:'530', background:'white', isWindowless:'false', framerate:'24', enableFramerateCounter:'false', version:'1.0'}, events:{onError:null, onLoad:null, onResize:null}, context:null});
    
}

